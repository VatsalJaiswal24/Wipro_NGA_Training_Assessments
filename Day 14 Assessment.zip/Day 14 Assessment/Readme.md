Day 14 -
## Problem Statement - 

1.	Write a JavaScript program that uses the Fetch API to retrieve data from a given JSON endpoint (e.g., "https://dummy.restapiexample.com/api/v1/employees"). Once the data is retrieved, display it on the console.

2.	Create an HTML page with a button. Write a JavaScript program that, upon a button click makes a Fetch API request to a random user API (e.g., "https://randomuser.me/api/") displays information about a random user, such as their name, email, and profile picture, on the webpage.
