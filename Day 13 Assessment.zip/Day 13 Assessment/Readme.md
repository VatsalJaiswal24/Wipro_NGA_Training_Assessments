# Student Management Sprint 2
## Problem Statement

Spring Flowers school wants to manage their students online:-

## User Stories :-

1.	As a Student, I should be able to see TimeTable button on the menu as well.
2.	As a Student. I should be able to see my Time Table after clicking the TimeTable button.
3.	As a student. I should be able to Open and see my school application on mobile.

## Instructions:-

1.	Please reuse the application created in sprint 1
2.	Please use HTML 5 and CSS 3 concepts
3.	Try to make a proper application
4.	Deploy the application on http server
5.	Please make sure the application should Responsive
6.	Please use flex box to arrange the content.
7.	Use Bootstrap to beautify the layout for eg: TimeTable , button etc.
