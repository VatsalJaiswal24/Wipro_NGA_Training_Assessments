package com.gl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxrouterApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxrouterApplication.class, args);
	}

}

// Created by Vatsal Jaiswal
