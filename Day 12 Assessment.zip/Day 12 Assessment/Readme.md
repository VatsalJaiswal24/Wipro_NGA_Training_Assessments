Coding Challenge Day 12
## Problem Statement 
 
# StudentManagement Spring 1 
 
## Problem Statement Spring Flowers school wants to manage their students online:- 
 
## User Stories :-  
1.	As a student. I should be able to see the Welcome page of my application. 
2.	As a Student. I should be able to see a MENU bar and School logo 
3. As a Student. I should be able to see my information after clicking Student Profile Button 
 
## Instructions:- 
1. Please use HTML 5 and CSS 3 concepts 
2. Try to make a proper application 
3. Deploy the application on http server Sample Output 
 
